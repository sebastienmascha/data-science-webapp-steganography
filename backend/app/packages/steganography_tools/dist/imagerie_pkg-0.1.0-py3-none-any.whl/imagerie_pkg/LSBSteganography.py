#! /usr/bin/env python3
# -*- coding: utf-8 -*-

def get_last_job_offers():
    print("Cooool")