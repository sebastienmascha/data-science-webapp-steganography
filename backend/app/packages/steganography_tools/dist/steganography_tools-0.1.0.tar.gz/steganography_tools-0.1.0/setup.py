# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['steganography_tools']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['cli_command_hello = steganography_tools:main']}

setup_kwargs = {
    'name': 'steganography-tools',
    'version': '0.1.0',
    'description': 'A Python library for higher level python functions used in image analysis and computer vision',
    'long_description': '',
    'author': 'Seb Mascha Name',
    'author_email': 'sebastien.mascha@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/sebastienmascha/package_name',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
